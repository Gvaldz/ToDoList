import Title from "../atoms/Title"
import './TitleSection.css'

function TitleSection() {

    return(
        <div id = "Title">
            <Title text = "To Do List" ></Title>
        </div>
    )
    
}

export default TitleSection