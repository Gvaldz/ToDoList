import React, { useState } from "react";
import Field from "../molecules/Field"
import Button from "../atoms/Button"
import Swal from "sweetalert2";
import './AddSection.css'

function AddSection({addTask}) {
    const [values, setValues] = useState({
        titulo: '',
        descripcion: '',
    });


    const handleSubmit = (event) => {
        event.preventDefault();

        const task = {
            titulo: values.titulo,
            descripcion: values.descripcion,
        };

        addTask(task);

        Swal.fire({
            title: "Tarea creada",
            icon: "success"
        });

        setValues({
            titulo: '',
            descripcion: '',
        });
    };

    return(
        <div id="dad">
            <form onSubmit={handleSubmit}>
        <div id="Add">
            <div id="fields">
            <Field 
            text = "Título"
            type = "text" 
            placeholder= "Ingrese el título" 
            val={values.titulo} 
            fnVal={(value) => setValues({ ...values, titulo: value })} 
            ></Field>
            <Field 
            text = "Descripción"
            type = "text" 
            placeholder= "Ingrese una descripción" 
            val={values.descripcion} 
            fnVal={(value) => setValues({ ...values, descripcion: value })} 
            ></Field>
            </div>
            <div id="button">
            <Button                
            title = "Agregar"
            color= "azul"
            onClick = {handleSubmit} >
            </Button>
            </div>

        </div>
        <div id="buttons">
            <div>
            <Button                
            title = "Pendientes"
            color= "azul">
            </Button>
            </div>
            <div>
            <Button                
            title = "Realizadas"
            color= "verde">
            </Button>
            </div>
            </div>
            </form>
        </div>
    )
    
}

export default AddSection