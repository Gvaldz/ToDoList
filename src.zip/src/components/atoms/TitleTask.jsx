import styled from "styled-components";

const TitleStyled = styled.h2`
    font-family: Arial, Helvetica, sans-serif;
    font-size: 25px;
    color: #ffffff;
    text-align: center;
    margin: 0;
`;


function TitleTask(props) {
    return(
        <TitleStyled>{props.text}</TitleStyled>
    )
}

export default TitleTask