


function Check() {

    return(
        <img src="check" alt="" />
    )
    
}

export default Check